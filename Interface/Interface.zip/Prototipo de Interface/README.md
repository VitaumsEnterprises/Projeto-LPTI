Vitor e Caio - aplicamos AJAX em cadastro.html
